# SPDX-FileCopyrightText: 2026 geisserml <geisserml@gmail.com>
# SPDX-License-Identifier: Apache-2.0 OR BSD-3-Clause

import os
import logging
import warnings
import pypdfium2_cfg


def _get_loglevel(envvar, default):
    return getattr(logging, os.environ.get(envvar, default).upper())

def setup_logging():
    
    # could also pass through the log level by parameter, but using an env var seemed easiest for now
    loglevel = _get_loglevel("PYPDFIUM_LOGLEVEL", "debug")
    loggers = [logging.getLogger("pypdfium2"+m) for m in ("", "_raw", "_cfg", "_cli")]
    streamhandler = logging.StreamHandler()
    for l in loggers:
        l.addHandler(streamhandler)
        l.setLevel(loglevel)
    
    warnings.simplefilter("always")
    
    # cli_logger = logging.getLogger("pypdfium2_cli")
    # cli_logger.debug("Just set up logging")
    
    debug_unsupported = bool(int( os.environ.get("DEBUG_UNSUPPORTED", 1) ))
    debug_sysfonts = bool(int( os.environ.get("DEBUG_SYSFONTS", 0) ))
    pypdfium2_cfg.DEBUG_AUTOCLOSE.value = _get_loglevel("DEBUG_AUTOCLOSE", "warning")
    
    import pypdfium2._helpers as pdfium
    from pypdfium2_cli._sysfonts import PdfSysfontListener
    if debug_unsupported:
        pdfium.PdfUnspHandler().setup()
    if debug_sysfonts:
        PdfSysfontListener().setup()
